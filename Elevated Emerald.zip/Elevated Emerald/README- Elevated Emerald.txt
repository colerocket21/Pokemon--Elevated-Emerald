
███████╗██╗░░░░░███████╗██╗░░░██╗░█████╗░████████╗███████╗██████╗░
██╔════╝██║░░░░░██╔════╝██║░░░██║██╔══██╗╚══██╔══╝██╔════╝██╔══██╗
█████╗░░██║░░░░░█████╗░░╚██╗░██╔╝███████║░░░██║░░░█████╗░░██║░░██║
██╔══╝░░██║░░░░░██╔══╝░░░╚████╔╝░██╔══██║░░░██║░░░██╔══╝░░██║░░██║
███████╗███████╗███████╗░░╚██╔╝░░██║░░██║░░░██║░░░███████╗██████╔╝
╚══════╝╚══════╝╚══════╝░░░╚═╝░░░╚═╝░░╚═╝░░░╚═╝░░░╚══════╝╚═════╝░

███████╗███╗░░░███╗███████╗██████╗░░█████╗░██╗░░░░░██████╗░
██╔════╝████╗░████║██╔════╝██╔══██╗██╔══██╗██║░░░░░██╔══██╗
█████╗░░██╔████╔██║█████╗░░██████╔╝███████║██║░░░░░██║░░██║
██╔══╝░░██║╚██╔╝██║██╔══╝░░██╔══██╗██╔══██║██║░░░░░██║░░██║
███████╗██║░╚═╝░██║███████╗██║░░██║██║░░██║███████╗██████╔╝
╚══════╝╚═╝░░░░░╚═╝╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝╚══════╝╚═════╝░
_____________________________________________________________________

In an alternate timeline, Rayquaza is unable to stop the Meteor in the Delta Episode
from crashing into the Hoenn region. Deoxys crashes into the ground and triggers an
event of cataclysmic proportions. The Hoenn region is buried in fallout from the
impact and this forces the Pokemon of the region to adapt to their new surroundings,
leading to them all making big changes in where and how they live. Now, years later
you are a young, aspiring trainer who must journey through the new Hoenn region and
its altered Pokemon inhabitants to try and become the Champion.

Welcome to ELEVATED EMERALD!

*ROM Hack made by Colerocket21*

Features:
------------------------------------------------------------------------------------------

+Every Pokemon from Gen 1-3 is available

+New Typings for every Pokemon (Gen 1-3)
    
      *Every typing possible has been used at least once

+Changed abilities for all Pokemon

+Custom Movesets for all Pokemon

+Custom Pokedex entries for every Pokemon

+Stat updates and changes

+Custom sprites (regular and shiny) for all Pokemon

+Increased Shiny Odds

+A few moves have been edited

+Important trainers have 6 Pokemon

+All trainers have custom teams

+Rare Candies are $1 at every mart to reduce the need to grind
 (Use at your own discression)

Notes:
-------------------------------------------------------------------------------------------

-The excel sheet should have most of the game data laid out for reference

- While I had a more in depth story planned out, minimal changes have been made to any in game text

     *General ideas I had in mind are listed on the 'Story' Tab of the Excel Sheet

-This is my first ROM Hack so there may be bugs.

-Play testing has been minimal so some Pokemon may be overpowered or broken.


Message from the Creator:
---------------------------------------------------------------------------------------------

Hello Reader,

My name is Cole and I was the one who made this ROM Hack. It has been a side project more or less
for about 3 years now. I am essentially releasing the game as a Beta since
I have not done any of the story editing as originally planned, but I feel as though the current
product is still enough for people to have a good time playing. That was the goal of this project
to begin with anyways. I have always been passionate about Pokemon and redesigning my first and
favorite game brought me joy and I hope that anyone who reads this or plays it is able to get that
same joy that I got from making it as they play. As stated above, this is my first ROM Hack so 
apologies if there are any glitches or bugs that I may not know about. If you find any, have any
questions, or just want to reach out in any way, feel free to shoot me a message on

Twitter: @colerocket21

Additionally, feel free to share this game with anyone who you think may enjoy it. I have no plans
of making money off this game or having it blow up in any way, but if it can bring smiles to 
peoples' faces then that is enough for me.

Thanks again for playing my game! Have fun!

-Colerocket21

------------------------------------------------------------------------------------------------

All rights to Pokemon and all of their assets belong to Nintendo and Gamefreak under trademark
and copyright laws.


------------------------------------------------------------------------------------------------

Known Bugs:

-Bag texture glitch: no effect on gameplay, but when you look at your items the backpack texture
                     is glitched

-Bad Egg: When you begin a game there will be a "Bad Egg" in PC box 3. I do not know why it is
          there, but I recommend not trying to hatch it as I do not know what it may or will
          do to your game. It may however give pokerus if you keep it in your party for a bit.

-The Trainers in Gym 4 have not be edited to fit the new typing of the pokemon or typing of the
 gym. I will fix this at a later date, but I have not had the time.

-Currently Suicuine is unobtainable as the location it should be found is coded improperly.
 Again, I will make fixing this issue a high priority, but haven't had the time recently.

-You currently cannot participate in contests because the Contest Center in Lilycove has a text
 glitch that I have not yet figured out how to fix.

-Levitate was renamed to the German "Levikorr." I do not know why, but the ability functions the
 same as it would otherwise.

-There may be a trainer or two that have Pokemon with no moves, resulting in them using struggle.
 If you find one please let me know so I can resolve the issue and then take your easy victory.

-If you find any other glitches, bugs, etc. feel free to contact me and report them. Thanks!


